import flet as ft
import json
import random

def main(page: ft.Page):
    # --- 画面設定 ---
    page.title = "社員名簿単語帳"
    page.theme_mode = "light"
    page.padding = 0
    page.spacing = 0
    page.fonts = {"Meiryo": "Meiryo UI", "Noto": "Noto Sans JP"}
    page.theme = ft.Theme(font_family="Noto") 

    # --- データ管理クラス (修正版) ---
    class DataManager:
        def __init__(self, page: ft.Page):
            self.page = page
            self.members = []
            # ★ここではまだロードしない（早すぎるため）
            # self.load_data() 

        def load_data(self):
            # ブラウザの保存領域からデータを読み込む
            try:
                # 念のため存在確認をしてから取得
                if self.page.client_storage.contains_key("members_data"):
                    stored_data = self.page.client_storage.get("members_data")
                    if stored_data:
                        self.members = stored_data
                    else:
                        self.members = []
                else:
                    self.members = []
            except Exception as e:
                print(f"データ読み込みエラー: {e}")
                self.members = []

        def save_data(self):
            self.page.client_storage.set("members_data", self.members)

        def add_member(self, name, title, memo):
            new_id = 1
            if self.members:
                new_id = max(m["id"] for m in self.members) + 1
            
            new_member = {
                "id": new_id,
                "name": name,
                "title": title,
                "memo": memo,
                "correct": 0,
                "total": 0
            }
            self.members.append(new_member)
            self.save_data()

        def update_stat(self, member_idx, is_correct):
            if 0 <= member_idx < len(self.members):
                self.members[member_idx]["total"] += 1
                if is_correct:
                    self.members[member_idx]["correct"] += 1
                self.save_data()

        def update_member(self, member_id, name, title, memo):
            for m in self.members:
                if m["id"] == member_id:
                    m["name"] = name
                    m["title"] = title
                    m["memo"] = memo
                    break
            self.save_data()

        def delete_member(self, member_id):
            self.members = [m for m in self.members if m["id"] != member_id]
            self.save_data()

    # pageを渡して初期化
    dm = DataManager(page)

    # --- 共通UIパーツ: 編集用ダイアログ ---
    edit_name_field = ft.TextField(label="氏名")
    edit_title_field = ft.TextField(label="役職")
    edit_memo_field = ft.TextField(label="その他・特徴", multiline=True)
    current_edit_id = None 

    def close_dialog(e):
        edit_dialog.open = False
        page.update()

    def save_edit(e):
        if current_edit_id is not None:
            dm.update_member(current_edit_id, edit_name_field.value, edit_title_field.value, edit_memo_field.value)
            edit_dialog.open = False
            update_list_view()
            page.snack_bar = ft.SnackBar(ft.Text("修正しました"))
            page.snack_bar.open = True
            page.update()

    edit_dialog = ft.AlertDialog(
        modal=True,
        title=ft.Text("情報を修正"),
        content=ft.Column([
            edit_name_field,
            edit_title_field,
            edit_memo_field
        ], width=400, height=300, scroll="auto"),
        actions=[
            ft.TextButton("キャンセル", on_click=close_dialog),
            ft.TextButton("保存", on_click=save_edit),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    page.dialog = edit_dialog

    # --- 1. 登録画面 ---
    name_field = ft.TextField(label="氏名", hint_text="例: 山田 太郎")
    title_field = ft.TextField(label="役職", hint_text="例: 部長")
    memo_field = ft.TextField(label="その他・特徴", hint_text="例: 眼鏡、ゴルフ好き", multiline=True)
    
    def add_click(e):
        if not name_field.value or not title_field.value:
            page.snack_bar = ft.SnackBar(ft.Text("氏名と役職は必須です"))
            page.snack_bar.open = True
            page.update()
            return
        
        dm.add_member(name_field.value, title_field.value, memo_field.value)
        
        name_field.value = ""
        title_field.value = ""
        memo_field.value = ""
        name_field.focus()
        
        page.snack_bar = ft.SnackBar(ft.Text("登録しました！"))
        page.snack_bar.open = True
        update_list_view() 
        page.update()

    register_view = ft.Container(
        padding=20,
        expand=True,
        alignment=ft.alignment.top_center,
        content=ft.Column([
            ft.Container(width=600, content=ft.Column([
                ft.Text("新規メンバー登録", size=24, weight="bold"),
                ft.Container(height=20),
                name_field,
                title_field,
                memo_field,
                ft.Container(height=20),
                ft.ElevatedButton(text="登録する", on_click=add_click, width=300, height=50)
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER))
        ], scroll="auto")
    )

    # --- 2. 学習画面 ---
    current_question = {"member": None, "index": -1, "mode": 1}
    
    question_text = ft.Text("まずはメンバーを登録してください", size=28, weight="bold", text_align=ft.TextAlign.CENTER)
    sub_text = ft.Text("", size=16, color=ft.colors.GREY)
    
    answer_field = ft.TextField(label="役職を入力", on_submit=lambda e: check_answer_mode1(e))
    submit_btn = ft.ElevatedButton(text="回答する", on_click=lambda e: check_answer_mode1(e), width=200, height=50)
    mode1_container = ft.Column([answer_field, submit_btn], visible=False, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=20)

    choices_column = ft.Column(visible=False, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10)

    feedback_text = ft.Text("", size=20, weight="bold")
    next_btn = ft.ElevatedButton(text="次の問題へ", on_click=lambda e: generate_question(), visible=False, width=200, height=50)

    def generate_question(e=None):
        if not dm.members:
            return
        feedback_text.value = ""
        next_btn.visible = False
        answer_field.value = ""
        
        idx = random.randint(0, len(dm.members) - 1)
        target = dm.members[idx]
        mode = random.choice([1, 2])
        current_question["member"] = target
        current_question["index"] = idx
        current_question["mode"] = mode

        if mode == 1:
            question_text.value = target["name"]
            sub_text.value = "この人の役職は？"
            mode1_container.visible = True
            choices_column.visible = False
        else:
            question_text.value = target["title"]
            sub_text.value = "この役職の人は誰？"
            mode1_container.visible = False
            choices_column.visible = True
            others = [m for i, m in enumerate(dm.members) if i != idx]
            if len(others) >= 3:
                dummies = random.sample(others, 3)
            else:
                dummies = others
            choices = dummies + [target]
            random.shuffle(choices)
            choices_column.controls.clear()
            for c in choices:
                btn = ft.OutlinedButton(
                    text=c["name"], 
                    data=c["id"],
                    width=300,
                    height=50,
                    on_click=lambda e, ans_id=c["id"]: check_answer_mode2(ans_id)
                )
                choices_column.controls.append(btn)
        page.update()

    def check_answer_mode1(e):
        user_ans = answer_field.value.strip()
        correct_ans = current_question["member"]["title"]
        is_correct = user_ans in correct_ans and len(user_ans) > 0
        result_process(is_correct, f"正解: {correct_ans}")

    def check_answer_mode2(selected_id):
        correct_id = current_question["member"]["id"]
        is_correct = (selected_id == correct_id)
        result_process(is_correct, f"正解: {current_question['member']['name']}")

    def result_process(is_correct, correct_msg):
        dm.update_stat(current_question["index"], is_correct)
        if is_correct:
            feedback_text.value = "正解！"
            feedback_text.color = ft.colors.GREEN
        else:
            feedback_text.value = f"不正解... ({correct_msg})"
            feedback_text.color = ft.colors.RED
        mode1_container.visible = False
        choices_column.visible = False
        next_btn.visible = True
        page.update()
        update_list_view()

    learn_view = ft.Container(
        padding=20,
        expand=True,
        alignment=ft.alignment.center,
        content=ft.Column([
            ft.Container(width=600, content=ft.Column([
                ft.Container(height=40),
                question_text,
                sub_text,
                ft.Container(height=20),
                mode1_container,
                choices_column,
                ft.Container(height=20),
                feedback_text,
                next_btn,
                ft.ElevatedButton(text="学習を開始する", on_click=generate_question)
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER))
        ], scroll="auto")
    )

    # --- 3. 進捗画面 ---
    list_view = ft.ListView(expand=True, spacing=10, padding=20)

    def confirm_delete(member_id):
        def on_yes(e):
            dm.delete_member(member_id)
            page.dialog.open = False
            update_list_view()
            page.snack_bar = ft.SnackBar(ft.Text("削除しました"))
            page.snack_bar.open = True
            page.update()
        
        def on_no(e):
            page.dialog.open = False
            page.update()

        confirm_dialog = ft.AlertDialog(
            title=ft.Text("削除の確認"),
            content=ft.Text("本当にこのデータを削除しますか？"),
            actions=[
                ft.TextButton("いいえ", on_click=on_no),
                ft.TextButton("はい", on_click=on_yes, style=ft.ButtonStyle(color=ft.colors.RED)),
            ],
        )
        page.dialog = confirm_dialog
        confirm_dialog.open = True
        page.update()

    def open_edit(member):
        nonlocal current_edit_id
        current_edit_id = member["id"]
        edit_name_field.value = member["name"]
        edit_title_field.value = member["title"]
        edit_memo_field.value = member["memo"]
        page.dialog = edit_dialog
        edit_dialog.open = True
        page.update()

    def update_list_view():
        list_view.controls.clear()
        if not dm.members:
            list_view.controls.append(
                ft.Container(
                    alignment=ft.alignment.center,
                    padding=20,
                    content=ft.Text("登録されたデータがありません", size=16)
                )
            )
        else:
            for m in dm.members:
                rate = 0
                if m["total"] > 0:
                    rate = int((m["correct"] / m["total"]) * 100)
                
                card = ft.Container(
                    padding=10,
                    bgcolor=ft.colors.WHITE,
                    border=ft.border.all(1, ft.colors.GREY_300),
                    border_radius=8,
                    width=600,
                    content=ft.Row([
                        ft.Container(
                            content=ft.Icon(ft.icons.PERSON, size=30, color=ft.colors.BLUE),
                            padding=ft.padding.only(left=10, right=15)
                        ),
                        ft.Column([
                            ft.Text(f"{m['name']}  ({m['title']})", size=18, weight="bold", color=ft.colors.BLACK),
                            ft.Text(f"正解: {m['correct']}/{m['total']} ({rate}%) | {m['memo']}", size=14, color=ft.colors.GREY)
                        ], expand=True),
                        
                        ft.Row([
                            ft.IconButton(
                                icon=ft.icons.EDIT, 
                                icon_color=ft.colors.BLUE_GREY,
                                tooltip="編集",
                                on_click=lambda e, mem=m: open_edit(mem)
                            ),
                            ft.IconButton(
                                icon=ft.icons.DELETE, 
                                icon_color=ft.colors.RED_400,
                                tooltip="削除",
                                on_click=lambda e, mid=m["id"]: confirm_delete(mid)
                            ),
                        ], spacing=0)
                        
                    ], alignment=ft.MainAxisAlignment.START)
                )
                list_view.controls.append(ft.Row([card], alignment=ft.MainAxisAlignment.CENTER))
        page.update()

    progress_view = ft.Container(
        expand=True,
        content=list_view
    )

    # --- メインレイアウト ---
    body_content = ft.Container(content=register_view, expand=True)

    def get_menu_color(selected_idx, current_idx):
        return ft.colors.BLUE if selected_idx == current_idx else ft.colors.GREY

    def switch_tab(e):
        idx = e.control.data
        if idx == 0:
            body_content.content = register_view
        elif idx == 1:
            body_content.content = learn_view
        elif idx == 2:
            body_content.content = progress_view
            update_list_view()
        
        for i, btn in enumerate([btn_reg, btn_learn, btn_prog]):
            color = get_menu_color(idx, i)
            btn.content.controls[0].color = color
            btn.content.controls[1].color = color
        
        page.update()

    def create_menu_btn(icon_name, text, idx):
        color = ft.colors.BLUE if idx == 0 else ft.colors.GREY
        return ft.Container(
            data=idx,
            expand=True,
            on_click=switch_tab,
            padding=10,
            content=ft.Column([
                ft.Icon(icon_name, color=color, size=24),
                ft.Text(text, size=11, color=color)
            ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2)
        )

    btn_reg = create_menu_btn(ft.icons.ADD, "登録", 0)
    btn_learn = create_menu_btn(ft.icons.SCHOOL, "学習", 1)
    btn_prog = create_menu_btn(ft.icons.LIST, "進捗", 2)

    bottom_menu = ft.Container(
        bgcolor=ft.colors.GREY_100,
        height=80, 
        padding=ft.padding.only(bottom=10),
        content=ft.Row([
            btn_reg,
            btn_learn,
            btn_prog
        ], alignment=ft.MainAxisAlignment.SPACE_EVENLY, vertical_alignment=ft.CrossAxisAlignment.CENTER)
    )

    page.add(
        ft.Column([
            body_content,
            ft.Divider(height=1, thickness=1, color=ft.colors.GREY_300),
            bottom_menu
        ], expand=True, spacing=0)
    )

    # ★ここが重要！画面を表示しきってからデータを読み込む
    dm.load_data()
    update_list_view()

ft.app(target=main)